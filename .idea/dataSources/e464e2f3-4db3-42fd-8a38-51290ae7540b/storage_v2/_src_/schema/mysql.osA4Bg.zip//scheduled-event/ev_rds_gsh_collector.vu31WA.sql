create definer = rdsadmin@localhost event ev_rds_gsh_collector on schedule
    every '5' MINUTE
        starts '2022-10-10 23:22:52'
    on completion preserve
    disable
    do
    CALL rds_collect_global_status_history();

